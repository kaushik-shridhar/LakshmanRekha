from shapely.geometry import Point, Polygon
import MySQLdb
from plyer import notification

def inside_test(point_x, point_y, floor_name):
    try:
        db_connection = MySQLdb.connect(
            "localhost",
            "root",
            "",
            "deep_blue"
        )
    except:
        print("Can't connect to database")

    # print("Connected")
    print(floor_name)

    cursor = db_connection.cursor()
    floor = floor_name.split(".")
    cursor.execute("SELECT coordinates FROM geofence_map WHERE name='" + floor[0] + "'")
    result = cursor.fetchone()
    print(result)
    x = result[0]
    final_result = []
    temp = ''
    temp_coords = []

    y = x.split('],')
    for i in y:
        for j in i:
            if j.isdigit():
                temp += j
            if j == ',':
                temp = int(temp)
                temp_coords.append(temp)
                temp = ''
        temp = int(temp)
        temp_coords.append(temp)
        temp = ''
        temp_coords = tuple(temp_coords)
        final_result.append(temp_coords)
        temp_coords = []

    # print(final_result)
    poly = Polygon(final_result)

    x = Point(point_x, point_y)

    if x.within(poly):
        return 'inside'
    else:
        return 'outside'

def notify():
    notification.notify(
        title = 'breach alert',
        message = 'patient x has breached the geofence',
        timeout = 1
    )

# new = inside_test(100, 250)
# print(new)