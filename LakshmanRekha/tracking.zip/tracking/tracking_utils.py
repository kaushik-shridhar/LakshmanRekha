import MySQLdb
from .background_check import add, background_check

def connect_to_db(host='localhost', username='root', password='', db_name='final'):
    try:
        mydb = MySQLdb.connect(
            host,
            username,
            password,
            db_name
        )
    except:
        print("Can't connect to database")
        return
    mycursor = mydb.cursor()
    return mydb, mycursor

def check_user(ssid, patient, floor_name, uid):
    mydb, mycursor = connect_to_db(db_name='final')
    sql1 = "SELECT * FROM users"
    mycursor.execute(sql1)
    result = mycursor.fetchall()
    flag = 0
    for i in range(len(result)):
        n_name = result[i][0]
        n_uid = result[i][1]
        n_floor = result[i][2]
        n_ssid = result[i][3]
        if (n_name == patient and n_uid == uid and n_floor == floor_name and n_ssid == ssid):
            flag = 1
        else:
            flag = 0
    if flag == 0:
        sql2 = "INSERT INTO users (name, uid, floor, ssid) VALUES ('"+str(patient)+"', '"+str(uid)+"', '"+str(floor_name)+"', '"+str(ssid)+"')"
        mycursor.execute(sql2)
        mydb.commit()
        # print("flag is 0")
    else:
        print("flag is 1")
        

def check_location(a):
    mydb, mycursor = connect_to_db()
    flag = 0
    # print(a)
    arr = a.split(",")
    # print(arr)
    for a in arr:
        try:
            y = a.split("/")
            # print(y)
            ssid = y[0]
            # print('ssid: ',ssid,'\n')
            rssi = y[1]
            # print('rssi',rssi)
            uid = y[2]
            # print('uid',uid)
            floor = y[3]
            # print('floor',floor)

            sql1 = "SELECT * FROM tracker"
            mycursor.execute(sql1)
            result1 = mycursor.fetchall()
            # print(result1)
            for i in range(len(result1)):
                n_ssid = result1[i][1]
                # print("for loop working")
                # print(i,'n_ssid',n_ssid)
                n_floor = result1[i][3]
                n_uid = result1[i][0]

                if (n_ssid == ssid and n_floor == floor and n_uid == uid):
                    # print(1, n_ssid, True)
                    # print("1st if working")
                    flag = 1
                    break
                    
            if flag == 1:
                # print('check',n_ssid)
                sql2 = "update tracker set rssi='"+str(rssi)+"' where ssid='"+str(n_ssid)+"' and uid='"+str(n_uid)+"' and floor_name='"+str(n_floor)+"'"
                mycursor.execute(sql2)
                # print("2nd if working")
                # print(n_ssid,'executed')
                mydb.commit()
                
            else:
                # print(ssid)
                sql3 = "SELECT mp FROM wifi WHERE ssid='"+str(ssid)+"'"
                # print(sql3)
                mycursor.execute(sql3)
                # print("3rd if working")
                result2 = mycursor.fetchone()
                # print(result2)
                # print(result2)
                
                sql2 = "INSERT INTO tracker (uid, ssid, rssi, floor_name, mp) VALUES ('"+str(uid)+"', '"+str(ssid)+"', '"+str(rssi)+"', '"+str(floor)+"', '"+str(result2[0])+"')"
                mycursor.execute(sql2)
                mydb.commit()
                # print("3rd if working")
            print(ssid)
            print(rssi)
            print(uid)
            print(floor)
            # add()
            background_check(ssid, rssi, uid, floor)
        except:
            pass
            # print('vataaaa')
            
            
    

# check_location("hello;hello;hello;hello,")