import MySQLdb
from .alert_system import *
# from .tracking_utils import *
from .trilateration import *
from .conversion import *

def connect_to_db(host='localhost', username='root', password='', db_name='final'):
    try:
        mydb = MySQLdb.connect(
            host,
            username,
            password,
            db_name
        )
    except:
        print("Can't connect to database")
        return
    mycursor = mydb.cursor()
    return mydb, mycursor

# def background_check():
#     try:
#         mydb = MySQLdb.connect(
# 			"localhost",
# 			"root",
# 			"",
# 			"dummy2"
# 		)
#     except:
#         print("Can't connect to database")
#         return
#     mycursor = mydb.cursor()
#     query = "SELECT center, floor_name FROM demo6 WHERE mac_id='user_1'"
#     mycursor.execute(query)
#     result = mycursor.fetchone()
#     print(result[1])
#     pts = result[0].split()
#     x = pts[0]
#     y = pts[1]
#     result = inside_test(float(x), float(y), result[1])
#     if (result == 'outside'):
#             notify()

def add():
    print("hello")
def background_check(ssid, rssi, uid, floor):
    print("bg check running")
    mydb, mycursor = connect_to_db()
    sql1 = "SELECT mp, rssi FROM tracker WHERE uid='"+str(uid)+"'"
    mycursor.execute(sql1)
    result1 = mycursor.fetchall()
    rssi = ''
    mp = ''
    for i in range(len(result1)):
        rssi += result1[i][0] + " "
        mp += result1[i][1] + " "
    mpa = mp.split(" ")
    rssia = rssi.split(" ")
    dist1 = float(convert_rssi(rssia[0], mpa[0]))
    dist2 = float(convert_rssi(rssia[1], mpa[0]))
    dist3 = float(convert_rssi(rssia[2], mpa[2]))
    center = trilaterate(dist1, dist2, dist3)
    s = str(200) +" "+str(200)
    pts = s.split(" ")#center.split(" ")
    result = inside_test(pts[0], pts[1], "floor_1⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮⸮.jpg")#floor)
    if (result == 'outside'):
        notify()

    
# background_check()