from django.apps import AppConfig


class TrackingConfig(AppConfig):
    name = 'tracking'
